<?php
define("SYSTEM_PATH", "http://localhost/law/")
        
    ?>
