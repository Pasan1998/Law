<style>
  /* Internal Styles */
  .welcome {
    display: inline-block;
    padding: 15px 30px;
    margin-right: 10px;
    font-size: 1.5rem;
    text-decoration: none;
    text-transform: uppercase;
    border-radius: 30px;
    transition: background-color 0.3s;
  }
  .welcome-primary {
    background-color: #007bff;
    color: #fff;
    border: none;
  }
  .welcome-primary:hover {
    background-color: #0056b3;
  }
  /* Keyframe animations */
  @keyframes slideInDown {
    from {
      transform: translateY(-50%);
      opacity: 0;
    }
    to {
      transform: translateY(0);
      opacity: 1;
    }
  }
  @keyframes zoomIn {
    from {
      transform: scale(0.5);
      opacity: 0;
    }
    to {
      transform: scale(1);
      opacity: 1;
    }
  }
  @media (max-width: 768px) {
  .service-item {
    width: 100%; /* Ensures the card takes full width on mobile */
    margin-left: auto;
    margin-right: auto;
  }
}

    @media (max-width: 576px) {
    .welcome {
      padding: 10px 20px; /* Reduce padding for smaller screens */
      font-size:  0.7rem;   /* Adjust font size */
      margin-right: 5px;
      border-radius: 20px; /* Adjust radius for smaller size */
    }

    .service-item {
    width: 100%; /* Ensures the card takes full width on mobile */
    margin-left: auto;
    margin-right: auto;
    }

    .carousel-control-prev-icon,
    .carousel-control-next-icon {
      width: 20px;  /* Smaller width for mobile */
      height: 20px; /* Smaller height for mobile */
      background-size: 100%; /* Ensures icon fills the reduced size */
    }
    
  }
  /* For very small mobile phones (portrait) */
@media (max-width: 575px) {
  .welcome {
      padding: 10px 20px; /* Reduce padding for smaller screens */
      font-size:  0.7rem;   /* Adjust font size */
      margin-right: 5px;
      border-radius: 20px; /* Adjust radius for smaller size */
    }

    .service-item {
    width: 100%; /* Ensures the card takes full width on mobile */
    margin-left: auto;
    margin-right: auto;
  } 
  .carousel-control-prev-icon,
  .carousel-control-next-icon {
      width: 20px;  /* Smaller width for mobile */
      height: 20px; /* Smaller height for mobile */
      background-size: 100%; /* Ensures icon fills the reduced size */
    }
}

/* For larger phones (landscape) */
@media (min-width: 576px) and (max-width: 767px) {
  .welcome {
      padding: 10px 20px; /* Reduce padding for smaller screens */
      font-size:  0.7rem;   /* Adjust font size */
      margin-right: 5px;
      border-radius: 20px; /* Adjust radius for smaller size */
    }
  .carousel-control-prev-icon,
  .carousel-control-next-icon {
      width: 20px;  /* Smaller width for mobile */
      height: 20px; /* Smaller height for mobile */
      background-size: 100%; /* Ensures icon fills the reduced size */
    }
    .service-item {
    width: 100%; /* Ensures the card takes full width on mobile */
    margin-left: auto;
    margin-right: auto;
  }

/* For tablets and smaller screens */
@media (min-width: 768px) and (max-width: 991px) {
  .welcome {
      padding: 10px 20px; /* Reduce padding for smaller screens */
      font-size:  0.7rem;   /* Adjust font size */
      margin-right: 5px;
      border-radius: 20px; /* Adjust radius for smaller size */
    }
  .carousel-control-prev-icon,
  .carousel-control-next-icon {
      width: 20px;  /* Smaller width for mobile */
      height: 20px; /* Smaller height for mobile */
      background-size: 100%; /* Ensures icon fills the reduced size */
    }

    .service-item {
    width: 100%; /* Ensures the card takes full width on mobile */
    margin-left: auto;
    margin-right: auto;
  }
}

/* For larger devices (desktops) */
@media (min-width: 992px) {
  .welcome {
      padding: 10px 20px; /* Reduce padding for smaller screens */
      font-size: 0.7rem;   /* Adjust font size */
      margin-right: 5px;
      border-radius: 20px; /* Adjust radius for smaller size */
    }
  .carousel-control-prev-icon,
  .carousel-control-next-icon {
      width: 20px;  /* Smaller width for mobile */
      height: 20px; /* Smaller height for mobile */
      
      .service-item {
    width: 100%; /* Ensures the card takes full width on mobile */
    margin-left: auto;
    margin-right: auto;
  }background-size: 100%; /* Ensures icon fills the reduced size */
    }
}
}
</style>

 
<!-- Navbar Start -->
<div class="container-fluid position-relative p-0">
    <nav class="navbar navbar-expand-lg navbar-dark px-5 py-3 py-lg-0">
    <a href="index.php" class="navbar-brand p-0">
            <h1 class="m-0">Perera Seneviratne Associates</h1>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="fa fa-bars"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto py-0">
                <a href="<?= SYSTEM_PATH ?>index.php" class="nav-item nav-link ">Home</a>
                <a href="<?= SYSTEM_PATH ?>about.php" class="nav-item nav-link">About</a>
                <!-- <a href="service.html" class="nav-item nav-link">Services</a> -->
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Practice Areas</a>
                    <div class="dropdown-menu m-0">

                        <?php
                        $sqlServices = "SELECT * FROM practice_areas where practiceAreaStatus = '1'";
                        $db = dbConn();
                        $resultServices = $db->query($sqlServices);
                        ?>
                        <?php
                        if ($resultServices->num_rows > 0) {
                            $i = 1;
                            while ($rowService = $resultServices->fetch_assoc()) {

                                $active_status = $rowService['HeadingNameOptionalStatus'];

                                if ($active_status == 1 ){
                                    $heading_name = $rowService['HeadingName'];
                                }else{
                                    $heading_name = $rowService['HeadingNameOptional'];
                                }

                                $text= $heading_name;
                                $curl = curl_init();
                                curl_setopt_array($curl, array(
                                    CURLOPT_URL => 'https://translate.googleapis.com/translate_a/single?client=gtx&dt=t',
                                    CURLOPT_RETURNTRANSFER => true,
                                    CURLOPT_ENCODING => '',
                                    CURLOPT_MAXREDIRS => 10,
                                    CURLOPT_TIMEOUT => 0,
                                    CURLOPT_FOLLOWLOCATION => true,
                                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                                    CURLOPT_CUSTOMREQUEST => 'POST',
                                    CURLOPT_POSTFIELDS => 'sl=en&tl=si&q=' . urlencode($text),
                                    CURLOPT_HTTPHEADER => array(
                                        'Content-Type: application/x-www-form-urlencoded'
                                    ),
                                )
                                );
                                $response = curl_exec($curl);
                                curl_close($curl);

                                $sentencesArray = json_decode($response, true);
                               
                                $sentences = "";
                                foreach ($sentencesArray[0] as $s) {
                                    $sentences .= isset($s[0]) ? $s[0] : '';
                                }

                                 $sentences;
                                ?>


                                <a href="<?= SYSTEM_PATH ?>servicearea.php?PracticeAreaId=<?= $rowService['PracticeAreaId'] ?>"
                                    class="dropdown-item" ><?= $heading_name ." ". $sentences ?>
                                </a>
                            <?php }
                        } ?>

                    </div>
                </div>
               
                <a href="<?= SYSTEM_PATH ?>blog.php" class="nav-item nav-link">Blog</a>
                <a href="<?= SYSTEM_PATH ?>contact.php" class="nav-item nav-link">Contact</a>
            </div>

    </nav>

    <div id="header-carousel" class="carousel slide carousel-fade" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="w-100" src="img/carousel-1.jpg" alt="Image">
                    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div class="p-3" style="max-width: 900px;">
                            <h5 class="text-white text-uppercase mb-3 animated slideInDown">Creative & Innovative</h5>
                            <h1 class="display-1 text-white mb-md-4 animated zoomIn">Protecting Your Rights</h1>
                            <a href="quote.php" class="btn btn-primary welcome py-md-3 px-md-5 me-3 animated slideInLeft">Book Free Consultation</a>
                            <!-- <a href="" class="btn btn-outline-light py-md-3 px-md-5 animated slideInRight">Contact Us</a> -->
                        </div>
                    </div> 
                </div>
                <div class="carousel-item">
                    <img class="w-100" src="img/carousel-2.jpg" alt="Image">
                    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                        <div class="p-3" style="max-width: 900px;">
                            <h5 class="text-white text-uppercase mb-3 animated slideInDown">Creative & Innovative</h5>
                            <h1 class="display-1 text-white mb-md-4 animated zoomIn">Advocating for Justice</h1>
                            <a href="quote.php" class="btn btn-primary welcome welcome-primary py-md-3 px-md-5 me-3 animated slideInLeft">Book Free Consultation</a>
                            <!-- <a href="" class="btn btn-outline-light py-md-3 px-md-5 animated slideInRight">Contact Us</a> -->
                        </div>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#header-carousel"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#header-carousel"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
</div>
<!-- Navbar End -->