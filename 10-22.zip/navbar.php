
<div class="container-fluid position-relative p-0">
    <nav class="navbar navbar-expand-lg navbar-dark px-5 py-3 py-lg-0" >
        <!-- <a href="index.php" class="navbar-brand p-0">
        <h1 class="m-0 display-5 display-md-4 display-lg-3">Perera Seneviratne Associates</h1>
        </a> -->
        <!-- <a href="index.php" class="navbar-brand p-0">
            <h1 class="m-0 ">Perera Seneviratne Associates</h1>
        </a> -->
        <a href="index.php" class="navbar-brand p-0">
            <h1 class="m-0 text-wrap text-center fs-4 fs-md-3 fs-lg-2">Perera Seneviratne Associates</h1>
        </a>


        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="fa fa-bars"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto py-0">
                <a href="<?= SYSTEM_PATH ?>index.php" class="nav-item nav-link ">Home</a>
                <a href="<?= SYSTEM_PATH ?>about.php" class="nav-item nav-link">About</a>

                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Practice Areas</a>
                    <div class="dropdown-menu m-0">

                        <?php
                        $sqlServices = "SELECT * FROM practice_areas where practiceAreaStatus = '1'";
                        $db = dbConn();
                        $resultServices = $db->query($sqlServices);
                        ?>
                        <?php
                        if ($resultServices->num_rows > 0) {
                            $i = 1;
                            while ($rowService = $resultServices->fetch_assoc()) {

                                $active_status = $rowService['HeadingNameOptionalStatus'];

                                if ($active_status == 1) {
                                    $heading_name = $rowService['HeadingName'];
                                } else {
                                    $heading_name = $rowService['HeadingNameOptional'];
                                }
                                // echo $heading_name;
                        
                                $text = $heading_name;
                                $curl = curl_init();
                                curl_setopt_array(
                                    $curl,
                                    array(
                                        CURLOPT_URL => 'https://translate.googleapis.com/translate_a/single?client=gtx&dt=t',
                                        CURLOPT_RETURNTRANSFER => true,
                                        CURLOPT_ENCODING => '',
                                        CURLOPT_MAXREDIRS => 10,
                                        CURLOPT_TIMEOUT => 0,
                                        CURLOPT_FOLLOWLOCATION => true,
                                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                                        CURLOPT_CUSTOMREQUEST => 'POST',
                                        CURLOPT_POSTFIELDS => 'sl=en&tl=si&q=' . urlencode($text),
                                        CURLOPT_HTTPHEADER => array(
                                            'Content-Type: application/x-www-form-urlencoded'
                                        ),
                                    )
                                );
                                $response = curl_exec($curl);
                                curl_close($curl);

                                $sentencesArray = json_decode($response, true);
                                $sentences = "";
                                foreach ($sentencesArray[0] as $s) {
                                    $sentences .= isset($s[0]) ? $s[0] : '';
                                }

                                $sentences;
                                ?>


                                <a href="<?= SYSTEM_PATH ?>servicearea.php?PracticeAreaId=<?= $rowService['PracticeAreaId'] ?>"
                                    class="dropdown-item"><?php

                                    echo $heading_name . $sentences ?>
                                </a>
                            <?php }
                        } ?>

                    </div>
                </div>
                <a href="<?= SYSTEM_PATH ?>blog.php" class="nav-item nav-link">Blog</a>
                <a href="<?= SYSTEM_PATH ?>contact.php" class="nav-item nav-link">Contact</a>
            </div>
            <butaton type="button" class="btn text-primary ms-3" data-bs-toggle="modal" data-bs-target="#searchModal"><i
                    class="fa fa-search"></i></butaton>
        </div>
    </nav>